-- MariaDB dump 10.19  Distrib 10.4.32-MariaDB, for Win64 (AMD64)
--
-- Host: 127.0.0.1    Database: gembira_db
-- ------------------------------------------------------
-- Server version	10.4.32-MariaDB

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `absensi`
--

DROP TABLE IF EXISTS `absensi`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `absensi` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `pegawai_id` int(11) NOT NULL,
  `validated_by_id` int(11) DEFAULT NULL,
  `tanggal` date NOT NULL,
  `waktu_masuk` datetime DEFAULT NULL,
  `waktu_keluar` datetime DEFAULT NULL,
  `status_kehadiran` varchar(20) DEFAULT NULL,
  `foto_selfie` varchar(255) DEFAULT NULL,
  `lokasi_absensi` varchar(100) DEFAULT NULL,
  `qr_code_scanned` varchar(255) DEFAULT NULL,
  `keterangan` longtext DEFAULT NULL,
  `ip_address` varchar(45) DEFAULT NULL,
  `user_agent` varchar(255) DEFAULT NULL,
  `status_validasi` varchar(20) NOT NULL,
  `catatan_admin` longtext DEFAULT NULL,
  `tanggal_validasi` datetime DEFAULT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` datetime DEFAULT NULL,
  `jenis_absensi` varchar(50) DEFAULT NULL,
  `jadwal_absensi_id` int(11) DEFAULT NULL,
  `konfigurasi_jadwal_id` int(11) DEFAULT NULL,
  `waktu_absensi` datetime DEFAULT NULL,
  `status` varchar(20) NOT NULL,
  `foto_path` varchar(255) DEFAULT NULL,
  `qr_code_used` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `IDX_352EBEB3998300D9` (`pegawai_id`),
  KEY `IDX_352EBEB3C69DE5E5` (`validated_by_id`),
  KEY `IDX_352EBEB3A9D7348A` (`jadwal_absensi_id`),
  KEY `IDX_352EBEB3C26A3AC9` (`konfigurasi_jadwal_id`),
  CONSTRAINT `FK_352EBEB3998300D9` FOREIGN KEY (`pegawai_id`) REFERENCES `pegawai` (`id`),
  CONSTRAINT `FK_352EBEB3A9D7348A` FOREIGN KEY (`jadwal_absensi_id`) REFERENCES `jadwal_absensi` (`id`),
  CONSTRAINT `FK_352EBEB3C26A3AC9` FOREIGN KEY (`konfigurasi_jadwal_id`) REFERENCES `konfigurasi_jadwal_absensi` (`id`),
  CONSTRAINT `FK_352EBEB3C69DE5E5` FOREIGN KEY (`validated_by_id`) REFERENCES `admin` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `absensi`
--

LOCK TABLES `absensi` WRITE;
/*!40000 ALTER TABLE `absensi` DISABLE KEYS */;
INSERT INTO `absensi` VALUES (1,1,NULL,'2025-08-29','2025-08-29 19:35:00',NULL,'hadir',NULL,NULL,NULL,'Absensi dzikir malam',NULL,NULL,'',NULL,NULL,'2025-08-29 12:20:02',NULL,'dzikir_malam',9,NULL,NULL,'',NULL,NULL),(2,1,NULL,'2025-08-28','2025-08-28 19:30:00',NULL,'hadir',NULL,NULL,NULL,'Absensi dzikir malam kemarin',NULL,NULL,'',NULL,NULL,'2025-08-29 12:20:41',NULL,'dzikir_malam',9,NULL,NULL,'',NULL,NULL),(3,1,NULL,'2025-08-27','2025-08-27 06:45:00',NULL,'hadir',NULL,NULL,NULL,'Absensi ibadah pagi',NULL,NULL,'',NULL,NULL,'2025-08-29 12:21:50',NULL,'ibadah_pagi',1,NULL,NULL,'',NULL,NULL),(4,1,NULL,'2025-08-26','2025-08-26 07:15:00',NULL,'terlambat',NULL,NULL,NULL,'Absensi apel pagi terlambat',NULL,NULL,'',NULL,NULL,'2025-08-29 12:22:11',NULL,'apel_pagi',3,NULL,NULL,'',NULL,NULL),(5,1,NULL,'2025-08-25','2025-08-25 08:30:00',NULL,'hadir',NULL,NULL,NULL,'Absensi BBAQ',NULL,NULL,'',NULL,NULL,'2025-08-29 12:23:18',NULL,'bbaq',2,NULL,NULL,'',NULL,NULL);
/*!40000 ALTER TABLE `absensi` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `admin`
--

DROP TABLE IF EXISTS `admin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `admin` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `created_by_id` int(11) DEFAULT NULL,
  `username` varchar(50) NOT NULL,
  `nama_lengkap` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `password` varchar(255) NOT NULL,
  `role` varchar(20) NOT NULL,
  `status` varchar(20) NOT NULL,
  `permissions` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL COMMENT '(DC2Type:json)' CHECK (json_valid(`permissions`)),
  `nomor_telepon` varchar(15) DEFAULT NULL,
  `last_login_at` datetime DEFAULT NULL,
  `last_login_ip` varchar(45) DEFAULT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` datetime DEFAULT NULL,
  `unit_kerja_id` int(11) DEFAULT NULL,
  `kepala_bidang_id` int(11) DEFAULT NULL,
  `kepala_kantor_id` int(11) DEFAULT NULL,
  `nip` varchar(18) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `UNIQ_880E0D76F85E0677` (`username`),
  UNIQUE KEY `UNIQ_880E0D76E7927C74` (`email`),
  UNIQUE KEY `UNIQ_880E0D7659329EEA` (`nip`),
  KEY `IDX_880E0D76B03A8386` (`created_by_id`),
  KEY `IDX_880E0D76CBE1A536` (`unit_kerja_id`),
  KEY `IDX_880E0D762B1CAF22` (`kepala_bidang_id`),
  KEY `IDX_880E0D76F99640B7` (`kepala_kantor_id`),
  CONSTRAINT `FK_880E0D762B1CAF22` FOREIGN KEY (`kepala_bidang_id`) REFERENCES `kepala_bidang` (`id`),
  CONSTRAINT `FK_880E0D76B03A8386` FOREIGN KEY (`created_by_id`) REFERENCES `admin` (`id`),
  CONSTRAINT `FK_880E0D76CBE1A536` FOREIGN KEY (`unit_kerja_id`) REFERENCES `unit_kerja` (`id`),
  CONSTRAINT `FK_880E0D76F99640B7` FOREIGN KEY (`kepala_kantor_id`) REFERENCES `kepala_kantor` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `admin`
--

LOCK TABLES `admin` WRITE;
/*!40000 ALTER TABLE `admin` DISABLE KEYS */;
INSERT INTO `admin` VALUES (1,NULL,'admin','Administrator Gembira','admin@gembira.com','$2y$13$G8WoUNkMcYQhEwPLqjMQBefNPAY47A7i3I5.DF15b/TKw/PJu4XIS','super_admin','aktif','[\"kelola_pegawai\",\"kelola_jadwal\",\"validasi_absensi\",\"laporan\",\"kelola_admin\"]',NULL,NULL,NULL,'2025-08-27 15:04:30',NULL,NULL,NULL,NULL,NULL),(2,NULL,'123456789','Ahmad Budiman','123456789@example.com','$2y$13$0l4KRUQ/wiMTkG0Inxwtj.Ki3i6JDUC7PhSZK.gT7c4joJcQ90NzC','pegawai','aktif','[\"absensi_pegawai\",\"profile_pegawai\"]',NULL,NULL,NULL,'2025-09-03 09:37:45',NULL,4,3,NULL,'123456789'),(3,NULL,'198201262008011013','Faisal Kasim','bagaya@gmail.com','$2y$13$VegjlouGTDLFqoFGEkBK/upnmyn84ymQ2v/bKBe/LSFZzeXeAOka6','pegawai','aktif','[\"absensi_pegawai\",\"profile_pegawai\"]','082312110045',NULL,NULL,'2025-09-03 09:37:45',NULL,1,1,NULL,'198201262008011013'),(4,NULL,'198308012009101001','SYAMSUL, SE','syamsul@example.com','$2y$13$BHoEv4WUzBHdd.uv5x/fUe5NeqvBQNz8ujn03SMQJjWemCZi8zXOu','pegawai','aktif','[\"absensi_pegawai\",\"profile_pegawai\"]',NULL,NULL,NULL,'2025-09-03 09:37:46',NULL,2,4,NULL,'198308012009101001'),(5,NULL,'197709072009101002','ABD. KADIR AMIN, S. HI','kadir@example.com','$2y$13$gjZzg3y1EwyLN/M2m3VYvOFqUspOENWwjefkbdWQq.5RhInfM7zKC','pegawai','aktif','[\"absensi_pegawai\",\"profile_pegawai\"]',NULL,NULL,NULL,'2025-09-03 09:37:46',NULL,3,2,NULL,'197709072009101002'),(6,NULL,'197709152008011010','TAUHID, S.Ag','tauhid@example.com','$2y$13$f7ldIb9PFlTiOcJyYUn0LOUzFxJM/a.q0SoN/tM9PmU6UU.oLDPsu','pegawai','aktif','[\"absensi_pegawai\",\"profile_pegawai\"]',NULL,NULL,NULL,'2025-09-03 09:37:47',NULL,4,3,NULL,'197709152008011010'),(7,NULL,'199807222025211004','BHAKTY MAULANA, S.H','bhaktry@example.com','$2y$13$sJXpsQ2PnB6r7H4U4c3Xh.DnQh4zOYmTI874wXpjUEbAr23YDeYhG','pegawai','aktif','[\"absensi_pegawai\",\"profile_pegawai\"]',NULL,NULL,NULL,'2025-09-03 09:37:47',NULL,5,5,NULL,'199807222025211004');
/*!40000 ALTER TABLE `admin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `doctrine_migration_versions`
--

DROP TABLE IF EXISTS `doctrine_migration_versions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `doctrine_migration_versions` (
  `version` varchar(191) NOT NULL,
  `executed_at` datetime DEFAULT NULL,
  `execution_time` int(11) DEFAULT NULL,
  PRIMARY KEY (`version`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `doctrine_migration_versions`
--

LOCK TABLES `doctrine_migration_versions` WRITE;
/*!40000 ALTER TABLE `doctrine_migration_versions` DISABLE KEYS */;
INSERT INTO `doctrine_migration_versions` VALUES ('DoctrineMigrations\\Version20250827060914','2025-08-27 13:09:33',444),('DoctrineMigrations\\Version20250827070641','2025-08-27 14:06:49',90),('DoctrineMigrations\\Version20250827074341','2025-08-27 14:46:23',45),('DoctrineMigrations\\Version20250827091751','2025-08-27 16:18:08',96),('DoctrineMigrations\\Version20250827142009','2025-08-27 21:21:08',116),('DoctrineMigrations\\Version20250827143141','2025-08-27 21:32:15',19),('DoctrineMigrations\\Version20250828034039','2025-08-28 10:42:56',152),('DoctrineMigrations\\Version20250828034218','2025-08-28 10:42:56',2),('DoctrineMigrations\\Version20250828035856','2025-08-28 10:59:10',11),('DoctrineMigrations\\Version20250828082916','2025-08-28 15:29:33',222),('DoctrineMigrations\\Version20250828083305','2025-08-28 15:36:29',179),('DoctrineMigrations\\Version20250829091327','2025-08-29 16:13:44',204),('DoctrineMigrations\\Version20250829093013','2025-08-29 16:30:29',38),('DoctrineMigrations\\Version20250829115653','2025-08-29 18:57:40',184),('DoctrineMigrations\\Version20250829124803','2025-08-29 19:48:32',124),('DoctrineMigrations\\Version20250829140203','2025-08-29 21:03:57',49),('DoctrineMigrations\\Version20250831081504','2025-08-31 15:15:21',31),('DoctrineMigrations\\Version20250902025832','2025-09-02 09:58:50',73),('DoctrineMigrations\\Version20250902025952','2025-09-02 10:00:24',89),('DoctrineMigrations\\Version20250903023036','2025-09-03 09:30:50',110),('DoctrineMigrations\\Version20250903040023','2025-09-03 11:00:30',17),('DoctrineMigrations\\Version20250908000001','2025-09-08 23:11:41',296);
/*!40000 ALTER TABLE `doctrine_migration_versions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `event`
--

DROP TABLE IF EXISTS `event`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `event` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `created_by_id` int(11) DEFAULT NULL,
  `deskripsi` longtext DEFAULT NULL,
  `kategori_event` varchar(50) NOT NULL,
  `warna` varchar(7) DEFAULT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` datetime DEFAULT NULL,
  `judul_event` varchar(150) NOT NULL,
  `tanggal_mulai` datetime NOT NULL,
  `tanggal_selesai` datetime DEFAULT NULL,
  `lokasi` varchar(200) DEFAULT NULL,
  `status` varchar(20) NOT NULL,
  `butuh_absensi` tinyint(1) NOT NULL DEFAULT 0,
  `link_meeting` varchar(500) DEFAULT NULL,
  `target_audience` varchar(10) NOT NULL DEFAULT 'all',
  `target_units` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL COMMENT '(DC2Type:json)' CHECK (json_valid(`target_units`)),
  `jam_mulai_absensi` time DEFAULT NULL,
  `jam_selesai_absensi` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `IDX_3BAE0AA7B03A8386` (`created_by_id`),
  CONSTRAINT `FK_3BAE0AA7B03A8386` FOREIGN KEY (`created_by_id`) REFERENCES `admin` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=25 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `event`
--

LOCK TABLES `event` WRITE;
/*!40000 ALTER TABLE `event` DISABLE KEYS */;
INSERT INTO `event` VALUES (1,NULL,'Peringatan hari kemerdekaan Indonesia ke-80','hari_besar','#FF0000','2025-08-29 13:13:35',NULL,'Hari Proklamasi Kemerdekaan RI','2025-08-17 00:00:00',NULL,NULL,'aktif',0,NULL,'all',NULL,NULL,NULL),(2,NULL,'Rapat koordinasi semua unit kerja bulan Agustus','kegiatan_kantor','#87CEEB','2025-08-29 13:13:35',NULL,'Rapat Koordinasi Bulanan','2025-08-30 00:00:00',NULL,NULL,'aktif',0,NULL,'all',NULL,NULL,NULL),(3,NULL,'Hari raya umat Islam','hari_besar','#00FF00','2025-08-29 13:13:35',NULL,'Hari Raya Idul Fitri','2025-09-01 00:00:00',NULL,NULL,'aktif',0,NULL,'all',NULL,NULL,NULL),(5,NULL,'Peringatan hari batik nasional','hari_khusus','#FFA500','2025-08-29 13:13:35',NULL,'Hari Batik Nasional','2025-10-02 00:00:00',NULL,NULL,'aktif',0,NULL,'all',NULL,NULL,NULL),(6,NULL,'Peringatan hari sumpah pemuda','hari_besar','#FF0000','2025-08-29 13:13:35',NULL,'Hari Sumpah Pemuda','2025-10-28 00:00:00',NULL,NULL,'aktif',0,NULL,'all',NULL,NULL,NULL),(7,NULL,'Peringatan hari pahlawan nasional','hari_besar','#FF0000','2025-08-29 13:13:35',NULL,'Hari Pahlawan','2025-11-10 00:00:00',NULL,NULL,'aktif',0,NULL,'all',NULL,NULL,NULL),(8,NULL,'Perayaan hari raya Natal','hari_besar','#00FF00','2025-08-29 13:13:35',NULL,'Hari Raya Natal','2025-12-25 00:00:00',NULL,NULL,'aktif',0,NULL,'all',NULL,NULL,NULL),(9,NULL,'Kegiatan dzikir bersama setelah maghrib','kegiatan_kantor','#87CEEB','2025-08-29 13:14:10',NULL,'Dzikir Bersama','2025-08-29 00:00:00',NULL,NULL,'aktif',0,NULL,'all',NULL,NULL,NULL),(10,NULL,'Evaluasi kinerja pegawai bulan Agustus','kegiatan_kantor','#87CEEB','2025-08-29 13:14:10',NULL,'Evaluasi Kinerja Bulanan','2025-08-31 00:00:00',NULL,NULL,'aktif',0,NULL,'all',NULL,NULL,NULL),(11,1,'Penanaman dan Berkebun','kegiatan_kantor','#87ceeb','2025-08-29 15:21:22',NULL,'Ekoteologi','2025-08-29 16:20:00','2025-08-29 16:20:00','Kanwil Kemenag Sulbar','aktif',0,NULL,'all',NULL,NULL,NULL),(12,1,'Bimtek GASPUL','kegiatan_kantor','#87ceeb','2025-08-29 16:17:19',NULL,'Bimtek Layanan Publik GASPUL','2025-08-29 15:16:00','2025-08-29 21:16:00','Kanwil Kemenag Sulbar','aktif',1,'https://us06web.zoom.us/j/83255451344?pwd=UmiZk1Cm2e3CMYrhfogJ7PG7Qarzwu.1','all',NULL,NULL,NULL),(13,1,NULL,'kegiatan_kantor','#87ceeb','2025-08-29 16:47:38',NULL,'Sosialisasi III','2025-08-29 17:47:00','2025-08-29 21:47:00','Kanwil Kemenag Sulbar','aktif',1,NULL,'custom','[1]',NULL,NULL),(14,1,'Rapat Tim PPID Kanwil','kegiatan_kantor','#87ceeb','2025-08-29 19:02:51',NULL,'Rapat PPID','2025-08-29 20:02:00','2025-08-29 21:02:00','Kanwil Kemenag Sulbar','aktif',1,NULL,'all','[]',NULL,NULL),(15,1,'Rapat Bidang Madrasah','kegiatan_internal','#87ceeb','2025-08-29 19:05:49',NULL,'Rapat Bidang Madrasah','2025-08-29 20:05:00','2025-08-29 21:05:00','Online','aktif',1,NULL,'custom','[]',NULL,NULL),(16,1,'Rapat Tim Kerja','kegiatan_kantor','#87ceeb','2025-08-29 20:08:01',NULL,'Rapat Tim Data dan Informasi','2025-08-29 21:07:00','2025-08-29 22:07:00','Online','aktif',1,NULL,'custom','[1]',NULL,NULL),(17,1,'rapat tim informasi dan data','kegiatan_kantor','#87ceeb','2025-08-29 20:47:03',NULL,'Rapat TIM INFORMASI dan DATA','2025-08-29 21:46:00','2025-08-29 22:15:00','Kanwil Kemenag Sulbar','aktif',1,NULL,'custom','[1]',NULL,NULL),(18,1,'Rapat Emis','kegiatan_kantor','#87ceeb','2025-08-29 21:23:53',NULL,'Rapat Tim Emis','2025-08-29 22:23:00','2025-08-29 22:43:00','Online','aktif',1,NULL,'custom','[2]',NULL,NULL),(19,1,'PPID Kanwil','kegiatan_kantor','#ece48e','2025-08-31 14:29:41',NULL,'Rapat PPID Kanwil','2025-08-31 15:29:00','2025-08-31 16:29:00','Online','aktif',1,NULL,'all','[]',NULL,NULL),(20,1,'bimtek gaspul','kegiatan_kantor','#87ceeb','2025-09-01 13:16:12',NULL,'Bimtek Gaspul II','2025-09-01 14:16:00','2025-09-01 16:16:00','','aktif',1,NULL,'all','[]',NULL,NULL),(21,1,'Rapat Haji','kegiatan_kantor','#331d9f','2025-09-02 09:16:52',NULL,'Rapat Persiapan Pemberangkatan Haji','2025-09-02 14:14:00','2025-09-02 15:14:00','Online','aktif',1,'https://us06web.zoom.us/j/85896781187?pwd=YgdaiBaJGbKqoa9Xx61pdcpa1FSa8w.1','all','[]',NULL,NULL),(22,1,'Evaluasi kinerja ASN','kegiatan_internal','#87ceeb','2025-09-03 10:47:15','2025-09-03 19:24:46','Evaluasi Kinerja ASN','2025-09-03 02:46:00','2025-09-03 04:46:00','Aula Kanwil','aktif',1,NULL,'all','[]','18:00:00','20:00:00'),(23,1,NULL,'kegiatan_kantor','#87ceeb','2025-09-04 07:48:53',NULL,'doa bersama','2025-09-04 07:50:00','2025-09-04 10:00:00','Online','aktif',1,'https://us06web.zoom.us/j/85896781187?pwd=YgdaiBaJGbKqoa9Xx61pdcpa1FSa8w.1','custom','[2]','08:00:00','09:47:00'),(24,1,'FGD Kanwil','kegiatan_kantor','#ec8e8e','2025-09-09 09:49:08','2025-09-09 22:28:56','FGD','2025-09-09 09:50:00','2025-09-09 11:00:00','Online','aktif',1,NULL,'all','[]','10:00:00','23:00:00');
/*!40000 ALTER TABLE `event` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `event_absensi`
--

DROP TABLE IF EXISTS `event_absensi`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `event_absensi` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `event_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `waktu_absen` datetime NOT NULL,
  `status` varchar(20) NOT NULL,
  `keterangan` longtext DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `unique_event_user` (`event_id`,`user_id`),
  KEY `IDX_B079171C71F7E88B` (`event_id`),
  KEY `IDX_B079171CA76ED395` (`user_id`),
  CONSTRAINT `FK_B079171C71F7E88B` FOREIGN KEY (`event_id`) REFERENCES `event` (`id`),
  CONSTRAINT `FK_B079171CA76ED395` FOREIGN KEY (`user_id`) REFERENCES `pegawai` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=17 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `event_absensi`
--

LOCK TABLES `event_absensi` WRITE;
/*!40000 ALTER TABLE `event_absensi` DISABLE KEYS */;
INSERT INTO `event_absensi` VALUES (1,12,1,'2025-08-29 16:17:44','hadir',NULL),(2,12,2,'2025-08-29 16:18:45','hadir',NULL),(3,12,3,'2025-08-29 18:08:54','hadir',NULL),(4,14,2,'2025-08-29 19:03:54','hadir',NULL),(5,18,3,'2025-08-29 21:28:05','hadir',NULL),(6,13,2,'2025-08-30 22:33:46','hadir',NULL),(7,17,2,'2025-08-31 14:25:10','hadir',NULL),(8,16,2,'2025-08-31 14:25:30','hadir',NULL),(9,19,2,'2025-08-31 14:30:49','hadir',NULL),(10,19,3,'2025-08-31 14:31:17','hadir',NULL),(11,19,4,'2025-08-31 14:38:36','hadir',NULL),(12,21,2,'2025-09-02 09:20:20','hadir',NULL),(13,22,2,'2025-09-03 19:24:57','hadir',NULL),(14,22,3,'2025-09-03 19:54:01','hadir',NULL),(15,23,3,'2025-09-04 08:02:57','hadir',NULL),(16,24,2,'2025-09-09 22:29:17','hadir',NULL);
/*!40000 ALTER TABLE `event_absensi` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `hari_libur`
--

DROP TABLE IF EXISTS `hari_libur`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `hari_libur` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `created_by_id` int(11) DEFAULT NULL,
  `tanggal_libur` date NOT NULL,
  `nama_libur` varchar(100) NOT NULL,
  `jenis_libur` varchar(20) NOT NULL,
  `keterangan` longtext DEFAULT NULL,
  `status` varchar(20) NOT NULL,
  `created_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `IDX_DADD3CC4B03A8386` (`created_by_id`),
  CONSTRAINT `FK_DADD3CC4B03A8386` FOREIGN KEY (`created_by_id`) REFERENCES `admin` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `hari_libur`
--

LOCK TABLES `hari_libur` WRITE;
/*!40000 ALTER TABLE `hari_libur` DISABLE KEYS */;
INSERT INTO `hari_libur` VALUES (1,NULL,'2025-01-01','Tahun Baru Masehi','nasional',NULL,'aktif','2025-08-28 21:43:09'),(2,NULL,'2025-08-17','Hari Kemerdekaan RI','nasional',NULL,'aktif','2025-08-28 21:43:09'),(3,NULL,'2025-12-25','Hari Raya Natal','nasional',NULL,'aktif','2025-08-28 21:43:09'),(4,1,'2026-01-03','Hari Amal Bakti Kemenag RI','nasional','Hari Amal Bakti Kemenag RI','aktif','2025-08-28 20:51:37');
/*!40000 ALTER TABLE `hari_libur` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `jadwal_absensi`
--

DROP TABLE IF EXISTS `jadwal_absensi`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `jadwal_absensi` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `created_by_id` int(11) DEFAULT NULL,
  `jenis_absensi` varchar(30) NOT NULL,
  `hari_diizinkan` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL COMMENT '(DC2Type:json)' CHECK (json_valid(`hari_diizinkan`)),
  `jam_mulai` time NOT NULL,
  `jam_selesai` time NOT NULL,
  `qr_code` varchar(255) DEFAULT NULL,
  `tanggal_khusus` date DEFAULT NULL,
  `is_aktif` tinyint(1) NOT NULL,
  `keterangan` longtext DEFAULT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` datetime DEFAULT NULL,
  `nama_custom` varchar(100) DEFAULT NULL,
  `emoji_custom` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `IDX_4FA2F0B03A8386` (`created_by_id`),
  CONSTRAINT `FK_4FA2F0B03A8386` FOREIGN KEY (`created_by_id`) REFERENCES `admin` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=14 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `jadwal_absensi`
--

LOCK TABLES `jadwal_absensi` WRITE;
/*!40000 ALTER TABLE `jadwal_absensi` DISABLE KEYS */;
INSERT INTO `jadwal_absensi` VALUES (1,1,'ibadah_pagi','[\"1\",\"2\",\"3\",\"4\"]','07:00:00','08:15:00',NULL,NULL,1,'Ibadah pagi rutin ASN setiap hari kerja','2025-08-27 16:19:44','2025-08-27 16:21:10',NULL,NULL),(2,1,'bbaq','[\"1\",\"2\",\"3\",\"4\"]','08:00:00','09:00:00',NULL,NULL,1,'Baca Buku Al-Quran setiap hari kerja','2025-08-27 16:19:44','2025-09-02 12:12:31',NULL,NULL),(3,1,'apel_pagi','[\"1\"]','07:00:00','08:15:00','AP_20250827_695696e7',NULL,1,'Apel pagi setiap hari Senin','2025-08-27 16:19:44','2025-08-27 16:29:04',NULL,NULL),(5,1,'upacara_nasional','[\"5\"]','07:30:00','08:30:00','UN_20250827_10f8af30','2025-08-29',1,NULL,'2025-08-27 17:07:28','2025-08-27 17:07:45',NULL,NULL),(9,NULL,'dzikir_malam','[\"1\",\"2\",\"3\",\"4\",\"5\",\"6\",\"7\"]','01:00:00','23:59:00',NULL,NULL,1,'Jadwal dzikir malam untuk semua pegawai','2025-08-29 12:19:37','2025-09-02 12:12:59','Dzikir Malam','🌙'),(13,1,'kegiatan_ekoteologi','[\"1\",\"2\"]','07:00:00','17:15:00',NULL,NULL,1,NULL,'2025-09-01 09:09:56',NULL,'Kegiatan Ekoteologi','🎯');
/*!40000 ALTER TABLE `jadwal_absensi` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `kepala_bidang`
--

DROP TABLE IF EXISTS `kepala_bidang`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `kepala_bidang` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `unit_kerja_id` int(11) NOT NULL,
  `nama` varchar(100) NOT NULL,
  `nip` varchar(18) NOT NULL,
  `jabatan` varchar(100) NOT NULL,
  `pangkat_gol` varchar(50) DEFAULT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `UNIQ_E1D486ED59329EEA` (`nip`),
  UNIQUE KEY `UNIQ_E1D486EDCBE1A536` (`unit_kerja_id`),
  CONSTRAINT `FK_E1D486EDCBE1A536` FOREIGN KEY (`unit_kerja_id`) REFERENCES `unit_kerja` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `kepala_bidang`
--

LOCK TABLES `kepala_bidang` WRITE;
/*!40000 ALTER TABLE `kepala_bidang` DISABLE KEYS */;
INSERT INTO `kepala_bidang` VALUES (1,1,'SUHARLI S.Ag., M.Pd','196911232005011004','Kepala Bagian Tata Usaha','IV/b','2025-08-28 17:34:45',NULL),(2,3,'H. SYAMSUL, S.Ag., M.Pd','197104121997031006','Kepala Bidang Papkis','IV/b Pembina Tingkat I','2025-08-31 13:20:56',NULL),(3,4,'AHMAD, S. Ag, MA','197212282000031002','Kepala Bidang Penyelenggaraan Haji dan Umrah','IV/b Pembina Tingkat I','2025-08-31 13:21:56',NULL),(4,2,'Dr. MISBAHUDDIN, S.Ag., M.Ag','197301112000031001','Kepala Bidang Madrasah','IV/b Pembina Tingkat I','2025-08-31 13:22:58',NULL),(5,5,'H. HAERUL, S.HI','198008272003121001','Kepala Bidang Bimas Islam','IV/a Pembina','2025-08-31 13:23:53',NULL);
/*!40000 ALTER TABLE `kepala_bidang` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `kepala_kantor`
--

DROP TABLE IF EXISTS `kepala_kantor`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `kepala_kantor` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nama` varchar(100) NOT NULL,
  `nip` varchar(18) NOT NULL,
  `jabatan` varchar(100) NOT NULL,
  `pangkat_gol` varchar(50) DEFAULT NULL,
  `periode` varchar(50) NOT NULL,
  `is_aktif` tinyint(1) NOT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `UNIQ_F73DC8B159329EEA` (`nip`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `kepala_kantor`
--

LOCK TABLES `kepala_kantor` WRITE;
/*!40000 ALTER TABLE `kepala_kantor` DISABLE KEYS */;
INSERT INTO `kepala_kantor` VALUES (1,'Dr. H. ADNAN MA','196912311991031024','Kepala Kanwil Kementerian Agama Provinsi Sulawesi Barat','IV/c','2024-2025',1,'2025-08-28 17:36:01',NULL);
/*!40000 ALTER TABLE `kepala_kantor` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `konfigurasi_jadwal_absensi`
--

DROP TABLE IF EXISTS `konfigurasi_jadwal_absensi`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `konfigurasi_jadwal_absensi` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `dibuat_oleh_id` int(11) NOT NULL,
  `nama_jadwal` varchar(100) NOT NULL,
  `deskripsi` longtext DEFAULT NULL,
  `hari_mulai` smallint(6) NOT NULL,
  `hari_selesai` smallint(6) NOT NULL,
  `jam_mulai` time NOT NULL,
  `jam_selesai` time NOT NULL,
  `perlu_qr_code` tinyint(1) NOT NULL,
  `perlu_kamera` tinyint(1) NOT NULL,
  `qr_code` varchar(255) DEFAULT NULL,
  `emoji` varchar(10) DEFAULT NULL,
  `warna_kartu` varchar(7) DEFAULT NULL,
  `is_aktif` tinyint(1) NOT NULL,
  `keterangan` longtext DEFAULT NULL,
  `dibuat` datetime NOT NULL,
  `diubah` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `IDX_2434BBFFAD547146` (`dibuat_oleh_id`),
  CONSTRAINT `FK_2434BBFFAD547146` FOREIGN KEY (`dibuat_oleh_id`) REFERENCES `admin` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `konfigurasi_jadwal_absensi`
--

LOCK TABLES `konfigurasi_jadwal_absensi` WRITE;
/*!40000 ALTER TABLE `konfigurasi_jadwal_absensi` DISABLE KEYS */;
INSERT INTO `konfigurasi_jadwal_absensi` VALUES (10,1,'Ibadah Pagi','Kegiatan Ibadah Pagi',2,4,'07:00:00','08:15:00',0,1,NULL,'🤲','#3B82F6',1,NULL,'2025-09-09 03:13:36',NULL),(11,1,'Apel Pagi','Apel Rutin',1,1,'07:00:00','08:15:00',0,1,NULL,'🏢','#EF4444',1,NULL,'2025-09-09 03:16:24',NULL),(12,1,'Tes Kamera dan QR','tes kamera dan qr',1,7,'07:00:00','23:59:00',1,1,'JDW_TES_KAMERA_DAN_QR_20250909_100650_4df31f','🇮🇩','#EF4444',1,NULL,'2025-09-09 10:03:28','2025-09-09 10:06:50');
/*!40000 ALTER TABLE `konfigurasi_jadwal_absensi` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `messenger_messages`
--

DROP TABLE IF EXISTS `messenger_messages`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `messenger_messages` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `body` longtext NOT NULL,
  `headers` longtext NOT NULL,
  `queue_name` varchar(190) NOT NULL,
  `created_at` datetime NOT NULL COMMENT '(DC2Type:datetime_immutable)',
  `available_at` datetime NOT NULL COMMENT '(DC2Type:datetime_immutable)',
  `delivered_at` datetime DEFAULT NULL COMMENT '(DC2Type:datetime_immutable)',
  PRIMARY KEY (`id`),
  KEY `IDX_75EA56E0FB7336F0` (`queue_name`),
  KEY `IDX_75EA56E0E3BD61CE` (`available_at`),
  KEY `IDX_75EA56E016BA31DB` (`delivered_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `messenger_messages`
--

LOCK TABLES `messenger_messages` WRITE;
/*!40000 ALTER TABLE `messenger_messages` DISABLE KEYS */;
/*!40000 ALTER TABLE `messenger_messages` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `notifikasi`
--

DROP TABLE IF EXISTS `notifikasi`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `notifikasi` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `pegawai_id` int(11) DEFAULT NULL,
  `event_id` int(11) DEFAULT NULL,
  `judul` varchar(200) NOT NULL,
  `pesan` longtext NOT NULL,
  `tipe` varchar(50) NOT NULL,
  `sudah_dibaca` tinyint(1) NOT NULL DEFAULT 0,
  `waktu_dibuat` datetime NOT NULL,
  `waktu_dibaca` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `IDX_468B5F3B998300D9` (`pegawai_id`),
  KEY `IDX_468B5F3B71F7E88B` (`event_id`),
  CONSTRAINT `FK_468B5F3B71F7E88B` FOREIGN KEY (`event_id`) REFERENCES `event` (`id`),
  CONSTRAINT `FK_468B5F3B998300D9` FOREIGN KEY (`pegawai_id`) REFERENCES `pegawai` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `notifikasi`
--

LOCK TABLES `notifikasi` WRITE;
/*!40000 ALTER TABLE `notifikasi` DISABLE KEYS */;
INSERT INTO `notifikasi` VALUES (1,1,14,'Event Baru: Rapat PPID','Event baru \"Rapat PPID\" telah dijadwalkan pada 29 August 2025, 20:02 di Kanwil Kemenag Sulbar. Kategori: Kegiatan Kantor\n\nDeskripsi: Rapat Tim PPID Kanwil\n\n⚠️ Event ini membutuhkan absensi. Jangan lupa untuk hadir dan melakukan absensi.','event_baru',0,'2025-08-29 19:02:51',NULL),(2,2,14,'Event Baru: Rapat PPID','Event baru \"Rapat PPID\" telah dijadwalkan pada 29 August 2025, 20:02 di Kanwil Kemenag Sulbar. Kategori: Kegiatan Kantor\n\nDeskripsi: Rapat Tim PPID Kanwil\n\n⚠️ Event ini membutuhkan absensi. Jangan lupa untuk hadir dan melakukan absensi.','event_baru',0,'2025-08-29 19:02:51',NULL),(3,3,14,'Event Baru: Rapat PPID','Event baru \"Rapat PPID\" telah dijadwalkan pada 29 August 2025, 20:02 di Kanwil Kemenag Sulbar. Kategori: Kegiatan Kantor\n\nDeskripsi: Rapat Tim PPID Kanwil\n\n⚠️ Event ini membutuhkan absensi. Jangan lupa untuk hadir dan melakukan absensi.','event_baru',0,'2025-08-29 19:02:51',NULL),(4,NULL,17,'Event Baru: Rapat TIM INFORMASI dan DATA','Event baru \"Rapat TIM INFORMASI dan DATA\" telah dijadwalkan pada 29 August 2025, 21:46 di Kanwil Kemenag Sulbar. Kategori: Kegiatan Kantor\n\nDeskripsi: rapat tim informasi dan data\n\n⚠️ Event ini membutuhkan absensi. Jangan lupa untuk hadir dan melakukan absensi.','event_baru',0,'2025-08-29 21:04:10',NULL),(5,NULL,13,'Event Baru: Sosialisasi III','Event baru \"Sosialisasi III\" telah dijadwalkan pada 29 August 2025, 17:47 di Kanwil Kemenag Sulbar. Kategori: Kegiatan Kantor\n\n⚠️ Event ini membutuhkan absensi. Jangan lupa untuk hadir dan melakukan absensi.','event_baru',0,'2025-08-29 21:12:20',NULL),(6,NULL,18,'Event Baru: Rapat Tim Emis','Event baru \"Rapat Tim Emis\" telah dijadwalkan pada 29 August 2025, 22:23 di Online. Kategori: Kegiatan Kantor\n\nDeskripsi: Rapat Emis\n\n⚠️ Event ini membutuhkan absensi. Jangan lupa untuk hadir dan melakukan absensi.','event_baru',0,'2025-08-29 21:23:53',NULL),(7,NULL,19,'Event Baru: Rapat PPID Kanwil','Event baru \"Rapat PPID Kanwil\" telah dijadwalkan pada 31 August 2025, 15:29 di Online. Kategori: Kegiatan Kantor\n\nDeskripsi: PPID Kanwil\n\n⚠️ Event ini membutuhkan absensi. Jangan lupa untuk hadir dan melakukan absensi.','event_baru',0,'2025-08-31 14:29:42',NULL),(8,NULL,20,'Event Baru: Bimtek Gaspul II','Event baru \"Bimtek Gaspul II\" telah dijadwalkan pada 01 September 2025, 14:16. Kategori: Kegiatan Kantor\n\nDeskripsi: bimtek gaspul\n\n⚠️ Event ini membutuhkan absensi. Jangan lupa untuk hadir dan melakukan absensi.','event_baru',0,'2025-09-01 13:16:12',NULL),(9,NULL,21,'Event Baru: Rapat Persiapan Pemberangkatan Haji','Event baru \"Rapat Persiapan Pemberangkatan Haji\" telah dijadwalkan pada 02 September 2025, 14:14 di Online. Kategori: Kegiatan Kantor\n\nDeskripsi: Rapat Haji\n\n⚠️ Event ini membutuhkan absensi. Jangan lupa untuk hadir dan melakukan absensi.','event_baru',0,'2025-09-02 09:16:52',NULL),(10,NULL,22,'Event Baru: Evaluasi Kinerja ASN','Event baru \"Evaluasi Kinerja ASN\" telah dijadwalkan pada 03 September 2025, 01:46 di Aula Kanwil. Kategori: Kegiatan Internal\n\nDeskripsi: Evaluasi kinerja ASN\n\n⚠️ Event ini membutuhkan absensi. Jangan lupa untuk hadir dan melakukan absensi.','event_baru',0,'2025-09-03 10:47:15',NULL),(11,NULL,23,'Event Baru: doa bersama','Event baru \"doa bersama\" telah dijadwalkan pada 04 September 2025, 07:50 di Online. Kategori: Kegiatan Kantor\n\n⚠️ Event ini membutuhkan absensi. Jangan lupa untuk hadir dan melakukan absensi.','event_baru',0,'2025-09-04 07:49:05',NULL),(12,NULL,24,'Event Baru: FGD','Event baru \"FGD\" telah dijadwalkan pada 09 September 2025, 09:50 di Online. Kategori: Kegiatan Kantor\n\nDeskripsi: FGD Kanwil\n\n⚠️ Event ini membutuhkan absensi. Jangan lupa untuk hadir dan melakukan absensi.','event_baru',0,'2025-09-09 09:49:11',NULL);
/*!40000 ALTER TABLE `notifikasi` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pegawai`
--

DROP TABLE IF EXISTS `pegawai`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pegawai` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nip` varchar(18) NOT NULL,
  `nama` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `password` varchar(255) NOT NULL,
  `jabatan` varchar(100) NOT NULL,
  `unit_kerja` varchar(100) DEFAULT NULL,
  `status_kepegawaian` varchar(20) NOT NULL,
  `tanggal_mulai_kerja` date NOT NULL,
  `nomor_telepon` varchar(15) DEFAULT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` datetime DEFAULT NULL,
  `roles` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL COMMENT '(DC2Type:json)' CHECK (json_valid(`roles`)),
  `unit_kerja_id` int(11) DEFAULT NULL,
  `tanda_tangan` varchar(255) DEFAULT NULL,
  `tanda_tangan_uploaded_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `UNIQ_9883574859329EEA` (`nip`),
  UNIQUE KEY `UNIQ_98835748E7927C74` (`email`),
  KEY `IDX_98835748CBE1A536` (`unit_kerja_id`),
  CONSTRAINT `FK_98835748CBE1A536` FOREIGN KEY (`unit_kerja_id`) REFERENCES `unit_kerja` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pegawai`
--

LOCK TABLES `pegawai` WRITE;
/*!40000 ALTER TABLE `pegawai` DISABLE KEYS */;
INSERT INTO `pegawai` VALUES (1,'123456789','Ahmad Budiman','123456789@example.com','$2y$13$TBT5.zJw4fanfjbhuddJH.k20YDVKav4Nx4FpPpDl5/Zo1Jmec3d.','Staff','Bagian Umum','aktif','2025-08-27',NULL,'2025-08-27 14:47:57','2025-08-31 13:24:42','[\"ROLE_USER\"]',4,NULL,NULL),(2,'198201262008011013','Faisal Kasim','bagaya@gmail.com','$2y$13$Suu1LJdyRpf7F4ntAof8YuF8qEW3ONUO2TSbyL9P1aeBIcrx1ukIO','Arsiparis Ahli Muda','Bagian Tata Usaha','aktif','2025-01-01','082312110045','2025-08-28 19:06:35','2025-09-02 09:18:43','[\"ROLE_USER\"]',1,'pegawai_198201262008011013.png','2025-09-02 09:18:43'),(3,'198308012009101001','SYAMSUL, SE','syamsul@example.com','$2y$13$4j2CSK9Pj4sSOKTB8r/R1ej6NFEnVZVELWtQF1zDzI.j6MDcsV4sy','Penelaah Teknis Kebijakan','Bidang Pendidikan Madrasah','aktif','2009-10-01',NULL,'2025-08-29 18:07:40','2025-09-03 19:53:37','[\"ROLE_USER\"]',2,'pegawai_198308012009101001.png','2025-09-03 19:53:37'),(4,'197709072009101002','ABD. KADIR AMIN, S. HI','kadir@example.com','$2y$13$NdMtvejWV2OR7XgPiB421eqg4DwFEujil.coCAKmWsfVq.EpinLC.','Penelaah Teknis Kebijakan','Bidang Pendidikan Agama dan Pendidikan Keagamaan Islam','aktif','2009-10-01',NULL,'2025-08-31 13:28:55',NULL,'[\"ROLE_USER\"]',3,NULL,NULL),(5,'197709152008011010','TAUHID, S.Ag','tauhid@example.com','$2y$13$zA/xUo/Z42L0l4Rv.tjhSugioREndYrt9ivquU1jBeF9ufG98t8yq','Analis Sumber Daya Manusia Aparatur Ahli Muda','Bidang Penyelenggaraan Haji dan Umrah','aktif','2008-01-01',NULL,'2025-08-31 13:33:44',NULL,'[\"ROLE_USER\"]',4,NULL,NULL),(6,'199807222025211004','BHAKTY MAULANA, S.H','bhaktry@example.com','$2y$13$FubOmd/IqqoRomoDBHfo6u4SBi3GdanGoMKubDvRtOLl/FfwHGfbG','Penata Layanan Operasional','Bidang Bimas Islam','aktif','2025-01-01',NULL,'2025-08-31 13:36:57',NULL,'[\"ROLE_USER\"]',5,NULL,NULL);
/*!40000 ALTER TABLE `pegawai` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sliders`
--

DROP TABLE IF EXISTS `sliders`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sliders` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(255) DEFAULT NULL,
  `description` text DEFAULT NULL,
  `image_path` varchar(255) NOT NULL,
  `order_no` int(11) DEFAULT 0,
  `status` enum('aktif','nonaktif') DEFAULT 'aktif',
  `link` varchar(500) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_status_order` (`status`,`order_no`),
  KEY `idx_order` (`order_no`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sliders`
--

LOCK TABLES `sliders` WRITE;
/*!40000 ALTER TABLE `sliders` DISABLE KEYS */;
INSERT INTO `sliders` VALUES (1,'Selamat Datang di GEMBIRA','Gerakan Munajat Bersama Untuk Kinerja - Aplikasi Absensi Gembira','Logo-Gaspul-68bf121f1a245.png',1,'aktif',NULL,'2025-09-03 17:38:02'),(2,'Tips Absensi Digital','Pastikan GPS aktif dan koneksi internet stabil untuk absensi yang akurat','sample-banner-2.jpg',2,'nonaktif',NULL,'2025-09-03 17:38:10'),(3,'Informasi Penting','Jangan lupa absensi sesuai jadwal yang ditentukan','logo-berakhlak-68b87e0fee1ce.png',3,'aktif',NULL,'2025-09-03 17:42:39');
/*!40000 ALTER TABLE `sliders` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `system_configuration`
--

DROP TABLE IF EXISTS `system_configuration`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `system_configuration` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `config_key` varchar(100) NOT NULL,
  `config_value` longtext DEFAULT NULL,
  `description` varchar(255) DEFAULT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` datetime DEFAULT NULL,
  `updated_by` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `UNIQ_BE4422B7A3B1F76E` (`config_key`),
  KEY `IDX_BE4422B716FE72E1` (`updated_by`),
  CONSTRAINT `FK_BE4422B716FE72E1` FOREIGN KEY (`updated_by`) REFERENCES `admin` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `system_configuration`
--

LOCK TABLES `system_configuration` WRITE;
/*!40000 ALTER TABLE `system_configuration` DISABLE KEYS */;
INSERT INTO `system_configuration` VALUES (1,'maintenance_mode','0','Mode pemeliharaan sistem','2025-09-09 00:11:41','2025-09-09 01:19:28',1),(2,'maintenance_message','Sistem sedang dalam pemeliharaan. Mohon coba beberapa saat lagi.','Pesan mode pemeliharaan','2025-09-09 00:11:41','2025-09-09 01:19:30',1);
/*!40000 ALTER TABLE `system_configuration` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `unit_kerja`
--

DROP TABLE IF EXISTS `unit_kerja`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `unit_kerja` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nama_unit` varchar(100) NOT NULL,
  `kode_unit` varchar(20) NOT NULL,
  `keterangan` varchar(500) DEFAULT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `UNIQ_5DD8A6A65188C48A` (`kode_unit`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `unit_kerja`
--

LOCK TABLES `unit_kerja` WRITE;
/*!40000 ALTER TABLE `unit_kerja` DISABLE KEYS */;
INSERT INTO `unit_kerja` VALUES (1,'Bagian Tata Usaha','01','Bagian TU','2025-08-28 17:29:14',NULL),(2,'Bidang Pendidikan Madrasah','02','Bidang Madrasah','2025-08-28 17:30:25',NULL),(3,'Bidang Pendidikan Agama dan Pendidikan Keagamaan Islam','03','Bidang Papkis','2025-08-31 13:17:58','2025-08-31 13:26:17'),(4,'Bidang Penyelenggaraan Haji dan Umrah','04','Bidang PHU','2025-08-31 13:18:27','2025-08-31 13:26:29'),(5,'Bidang Bimas Islam','05','Bidang Bimas Islam','2025-08-31 13:19:06','2025-08-31 13:26:05'),(6,'Bimas Kristen','06',NULL,'2025-09-09 09:30:23',NULL),(7,'Bimas Katolik','07',NULL,'2025-09-09 09:30:38',NULL),(8,'Bimas Hindu','08',NULL,'2025-09-09 09:30:57',NULL),(9,'Bimas Buddha','09',NULL,'2025-09-09 09:31:21',NULL);
/*!40000 ALTER TABLE `unit_kerja` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `user_notifikasi`
--

DROP TABLE IF EXISTS `user_notifikasi`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user_notifikasi` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `pegawai_id` int(11) NOT NULL,
  `notifikasi_id` int(11) NOT NULL,
  `is_read` tinyint(1) NOT NULL DEFAULT 0,
  `received_at` datetime NOT NULL,
  `read_at` datetime DEFAULT NULL,
  `priority` varchar(20) NOT NULL DEFAULT 'normal',
  PRIMARY KEY (`id`),
  KEY `IDX_E1EC99D7998300D9` (`pegawai_id`),
  KEY `IDX_E1EC99D7936D434` (`notifikasi_id`),
  CONSTRAINT `FK_E1EC99D7936D434` FOREIGN KEY (`notifikasi_id`) REFERENCES `notifikasi` (`id`),
  CONSTRAINT `FK_E1EC99D7998300D9` FOREIGN KEY (`pegawai_id`) REFERENCES `pegawai` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=40 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user_notifikasi`
--

LOCK TABLES `user_notifikasi` WRITE;
/*!40000 ALTER TABLE `user_notifikasi` DISABLE KEYS */;
INSERT INTO `user_notifikasi` VALUES (1,1,1,0,'2025-08-29 19:02:51',NULL,'normal'),(2,2,2,1,'2025-08-29 19:02:51','2025-08-29 20:02:59','normal'),(3,3,3,1,'2025-08-29 19:02:51','2025-08-29 20:08:19','normal'),(4,1,4,0,'2025-08-29 21:04:10',NULL,'high'),(5,2,4,1,'2025-08-29 21:04:10','2025-08-29 21:16:38','high'),(6,1,5,0,'2025-08-29 21:12:20',NULL,'high'),(7,2,5,1,'2025-08-29 21:12:20','2025-08-29 21:16:38','high'),(8,3,6,1,'2025-08-29 21:23:53','2025-08-29 21:27:40','high'),(9,1,7,0,'2025-08-31 14:29:42',NULL,'high'),(10,2,7,1,'2025-08-31 14:29:42','2025-08-31 14:30:13','high'),(11,3,7,1,'2025-08-31 14:29:42','2025-09-03 19:48:18','high'),(12,4,7,0,'2025-08-31 14:29:42',NULL,'high'),(13,5,7,0,'2025-08-31 14:29:42',NULL,'high'),(14,6,7,0,'2025-08-31 14:29:42',NULL,'high'),(15,1,8,0,'2025-09-01 13:16:13',NULL,'high'),(16,2,8,1,'2025-09-01 13:16:13','2025-09-02 09:08:01','high'),(17,3,8,1,'2025-09-01 13:16:13','2025-09-03 19:48:18','high'),(18,4,8,0,'2025-09-01 13:16:13',NULL,'high'),(19,5,8,0,'2025-09-01 13:16:13',NULL,'high'),(20,6,8,0,'2025-09-01 13:16:13',NULL,'high'),(21,1,9,0,'2025-09-02 09:16:52',NULL,'high'),(22,2,9,1,'2025-09-02 09:16:52','2025-09-02 09:17:17','high'),(23,3,9,1,'2025-09-02 09:16:52','2025-09-03 19:48:18','high'),(24,4,9,0,'2025-09-02 09:16:52',NULL,'high'),(25,5,9,0,'2025-09-02 09:16:52',NULL,'high'),(26,6,9,0,'2025-09-02 09:16:52',NULL,'high'),(27,1,10,0,'2025-09-03 10:47:16',NULL,'high'),(28,2,10,1,'2025-09-03 10:47:16','2025-09-03 11:05:43','high'),(29,3,10,1,'2025-09-03 10:47:16','2025-09-03 19:48:18','high'),(30,4,10,0,'2025-09-03 10:47:16',NULL,'high'),(31,5,10,0,'2025-09-03 10:47:16',NULL,'high'),(32,6,10,0,'2025-09-03 10:47:16',NULL,'high'),(33,3,11,1,'2025-09-04 07:49:05','2025-09-04 07:50:59','high'),(34,1,12,0,'2025-09-09 09:49:11',NULL,'high'),(35,2,12,1,'2025-09-09 09:49:11','2025-09-09 09:54:27','high'),(36,3,12,0,'2025-09-09 09:49:11',NULL,'high'),(37,4,12,0,'2025-09-09 09:49:11',NULL,'high'),(38,5,12,0,'2025-09-09 09:49:11',NULL,'high'),(39,6,12,0,'2025-09-09 09:49:11',NULL,'high');
/*!40000 ALTER TABLE `user_notifikasi` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping routines for database 'gembira_db'
--
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2025-09-09 23:15:29
