<?php

/**
 * This file has been auto-generated
 * by the Symfony Routing Component.
 */

return [
    false, // $matchHost
    [ // $staticRoutes
        '/_wdt/styles' => [[['_route' => '_wdt_stylesheet', '_controller' => 'web_profiler.controller.profiler::toolbarStylesheetAction'], null, null, null, false, false, null]],
        '/_profiler' => [[['_route' => '_profiler_home', '_controller' => 'web_profiler.controller.profiler::homeAction'], null, null, null, true, false, null]],
        '/_profiler/search' => [[['_route' => '_profiler_search', '_controller' => 'web_profiler.controller.profiler::searchAction'], null, null, null, false, false, null]],
        '/_profiler/search_bar' => [[['_route' => '_profiler_search_bar', '_controller' => 'web_profiler.controller.profiler::searchBarAction'], null, null, null, false, false, null]],
        '/_profiler/phpinfo' => [[['_route' => '_profiler_phpinfo', '_controller' => 'web_profiler.controller.profiler::phpinfoAction'], null, null, null, false, false, null]],
        '/_profiler/xdebug' => [[['_route' => '_profiler_xdebug', '_controller' => 'web_profiler.controller.profiler::xdebugAction'], null, null, null, false, false, null]],
        '/_profiler/open' => [[['_route' => '_profiler_open_file', '_controller' => 'web_profiler.controller.profiler::openAction'], null, null, null, false, false, null]],
        '/absensi' => [[['_route' => 'app_absensi_dashboard', '_controller' => 'App\\Controller\\AbsensiController::dashboardAbsensi'], null, ['GET' => 0], null, true, false, null]],
        '/absensi/riwayat' => [[['_route' => 'app_absensi_riwayat', '_controller' => 'App\\Controller\\AbsensiController::riwayatAbsensi'], null, ['GET' => 0], null, false, false, null]],
        '/absensi/api/status' => [[['_route' => 'app_absensi_api_status', '_controller' => 'App\\Controller\\AbsensiController::apiStatusAbsensi'], null, ['GET' => 0], null, false, false, null]],
        '/absensi/api/ranking-update' => [[['_route' => 'app_absensi_api_ranking_update', '_controller' => 'App\\Controller\\AbsensiController::apiRankingUpdate'], null, ['GET' => 0], null, false, false, null]],
        '/absensi/api/scan-qr' => [[['_route' => 'app_absensi_api_scan_qr', '_controller' => 'App\\Controller\\AbsensiController::apiScanQr'], null, ['POST' => 0], null, false, false, null]],
        '/admin/attendance-report' => [[['_route' => 'app_admin_attendance_report', '_controller' => 'App\\Controller\\AdminAttendanceReportController::index'], null, null, null, true, false, null]],
        '/admin/attendance-report/comparison' => [[['_route' => 'app_admin_attendance_comparison', '_controller' => 'App\\Controller\\AdminAttendanceReportController::perbandinganKehadiran'], null, null, null, false, false, null]],
        '/admin/attendance-report/export' => [[['_route' => 'app_admin_attendance_export', '_controller' => 'App\\Controller\\AdminAttendanceReportController::exportLaporan'], null, null, null, false, false, null]],
        '/admin' => [[['_route' => 'app_admin_dashboard', '_controller' => 'App\\Controller\\AdminController::dashboard'], null, null, null, true, false, null]],
        '/admin/pengaturan' => [[['_route' => 'app_admin_pengaturan', '_controller' => 'App\\Controller\\AdminController::pengaturan'], null, null, null, false, false, null]],
        '/admin/jadwal-absensi' => [[['_route' => 'app_admin_jadwal_absensi', '_controller' => 'App\\Controller\\AdminController::jadwalAbsensi'], null, null, null, false, false, null]],
        '/admin/jadwal-absensi/new' => [[['_route' => 'app_admin_jadwal_absensi_new', '_controller' => 'App\\Controller\\AdminController::newJadwalAbsensi'], null, null, null, false, false, null]],
        '/admin/jadwal-absensi/create' => [[['_route' => 'app_admin_create_jadwal', '_controller' => 'App\\Controller\\AdminController::createJadwalAbsensi'], null, ['POST' => 0], null, false, false, null]],
        '/admin/qr-codes' => [[['_route' => 'app_admin_qr_codes', '_controller' => 'App\\Controller\\AdminController::qrCodes'], null, null, null, false, false, null]],
        '/admin/clear-cache' => [[['_route' => 'app_admin_clear_cache', '_controller' => 'App\\Controller\\AdminController::clearCache'], null, ['POST' => 0], null, false, false, null]],
        '/admin/clean-old-files' => [[['_route' => 'app_admin_clean_old_files', '_controller' => 'App\\Controller\\AdminController::cleanOldFiles'], null, ['POST' => 0], null, false, false, null]],
        '/admin/maintenance/toggle' => [[['_route' => 'app_admin_maintenance_toggle', '_controller' => 'App\\Controller\\AdminController::toggleMaintenanceMode'], null, ['POST' => 0], null, false, false, null]],
        '/admin/maintenance/message' => [[['_route' => 'app_admin_maintenance_message', '_controller' => 'App\\Controller\\AdminController::updateMaintenanceMessage'], null, ['POST' => 0], null, false, false, null]],
        '/admin/backup/create' => [[['_route' => 'app_admin_backup_create', '_controller' => 'App\\Controller\\AdminController::createBackup'], null, ['POST' => 0], null, false, false, null]],
        '/admin/backup/list' => [[['_route' => 'app_admin_backup_list', '_controller' => 'App\\Controller\\AdminController::getBackupList'], null, ['GET' => 0], null, false, false, null]],
        '/admin/event' => [[['_route' => 'app_admin_event_index', '_controller' => 'App\\Controller\\AdminEventController::index'], null, null, null, true, false, null]],
        '/admin/event/new' => [[['_route' => 'app_admin_event_new', '_controller' => 'App\\Controller\\AdminEventController::new'], null, null, null, false, false, null]],
        '/admin/event/api/calendar-data' => [[['_route' => 'app_admin_event_calendar_api', '_controller' => 'App\\Controller\\AdminEventController::calendarApi'], null, null, null, false, false, null]],
        '/admin/event/api/unit-kerja' => [[['_route' => 'app_admin_event_api_unit_kerja', '_controller' => 'App\\Controller\\AdminEventController::getUnitKerjaApi'], null, null, null, false, false, null]],
        '/admin/laporan-bulanan' => [[['_route' => 'app_admin_laporan_bulanan', '_controller' => 'App\\Controller\\AdminLaporanBulananController::index'], null, null, null, true, false, null]],
        '/admin/laporan-bulanan/download-new' => [[['_route' => 'app_admin_laporan_bulanan_download_new', '_controller' => 'App\\Controller\\AdminLaporanBulananController::downloadLaporanBulananNew'], null, ['POST' => 0], null, false, false, null]],
        '/admin/laporan-bulanan/test-download' => [[['_route' => 'app_admin_laporan_bulanan_test_download', '_controller' => 'App\\Controller\\AdminLaporanBulananController::testDownload'], null, null, null, false, false, null]],
        '/admin/laporan-bulanan/download' => [[['_route' => 'app_admin_laporan_bulanan_download', '_controller' => 'App\\Controller\\AdminLaporanBulananController::downloadLaporanBulanan'], null, null, null, false, false, null]],
        '/admin/laporan-kehadiran' => [[['_route' => 'app_admin_laporan_kehadiran', '_controller' => 'App\\Controller\\AdminLaporanKehadiranController::index'], null, null, null, true, false, null]],
        '/admin/laporan-kehadiran/download' => [[['_route' => 'app_admin_laporan_kehadiran_download', '_controller' => 'App\\Controller\\AdminLaporanKehadiranController::downloadRekapData'], null, null, null, false, false, null]],
        '/admin/role' => [[['_route' => 'app_admin_role', '_controller' => 'App\\Controller\\AdminRoleController::index'], null, null, null, true, false, null]],
        '/admin/role/update-role-permissions' => [[['_route' => 'app_admin_role_update_permissions', '_controller' => 'App\\Controller\\AdminRoleController::updateRolePermissions'], null, ['POST' => 0], null, false, false, null]],
        '/admin/banner' => [[['_route' => 'app_admin_banner_index', '_controller' => 'App\\Controller\\AdminSliderController::index'], null, null, null, true, false, null]],
        '/admin/banner/new' => [[['_route' => 'app_admin_banner_new', '_controller' => 'App\\Controller\\AdminSliderController::new'], null, null, null, false, false, null]],
        '/admin/banner/create' => [[['_route' => 'app_admin_banner_create', '_controller' => 'App\\Controller\\AdminSliderController::create'], null, ['POST' => 0], null, false, false, null]],
        '/admin/user' => [[['_route' => 'app_admin_user', '_controller' => 'App\\Controller\\AdminUserController::index'], null, null, null, true, false, null]],
        '/admin/user/create' => [[['_route' => 'app_admin_user_create', '_controller' => 'App\\Controller\\AdminUserController::create'], null, ['POST' => 0], null, false, false, null]],
        '/admin/user/export-template' => [[['_route' => 'app_admin_user_export_template', '_controller' => 'App\\Controller\\AdminUserController::exportTemplate'], null, ['GET' => 0], null, false, false, null]],
        '/admin/user/preview-import' => [[['_route' => 'app_admin_user_preview_import', '_controller' => 'App\\Controller\\AdminUserController::previewImport'], null, ['POST' => 0], null, false, false, null]],
        '/admin/user/test-import' => [[['_route' => 'app_admin_user_test_import', '_controller' => 'App\\Controller\\AdminUserController::testImport'], null, ['GET' => 0], null, false, false, null]],
        '/admin/user/import-simple' => [[['_route' => 'app_admin_user_import_simple', '_controller' => 'App\\Controller\\AdminUserController::importSimple'], null, ['POST' => 0], null, false, false, null]],
        '/admin/user/import' => [[['_route' => 'app_admin_user_import', '_controller' => 'App\\Controller\\AdminUserController::import'], null, ['POST' => 0], null, false, false, null]],
        '/admin/user/sync-to-pegawai' => [[['_route' => 'app_admin_user_sync_pegawai', '_controller' => 'App\\Controller\\AdminUserController::syncToPegawai'], null, ['POST' => 0], null, false, false, null]],
        '/admin/validasi-absen' => [[['_route' => 'app_admin_validasi_absen', '_controller' => 'App\\Controller\\AdminValidasiAbsenController::index'], null, null, null, true, false, null]],
        '/admin/validasi-absen/bulk-action' => [[['_route' => 'app_admin_bulk_validation', '_controller' => 'App\\Controller\\AdminValidasiAbsenController::bulkAction'], null, ['POST' => 0], null, false, false, null]],
        '/' => [[['_route' => 'app_dashboard', '_controller' => 'App\\Controller\\DashboardFleksibelController::index'], null, null, null, false, false, null]],
        '/api/jadwal-update' => [[['_route' => 'app_api_jadwal_update', '_controller' => 'App\\Controller\\DashboardFleksibelController::apiJadwalUpdate'], null, ['GET' => 0], null, false, false, null]],
        '/admin/laporan' => [[['_route' => 'app_laporan', '_controller' => 'App\\Controller\\LaporanController::index'], null, null, null, true, false, null]],
        '/admin/laporan/rekap' => [[['_route' => 'app_laporan_rekap', '_controller' => 'App\\Controller\\LaporanController::rekap'], null, ['GET' => 0, 'POST' => 1], null, false, false, null]],
        '/admin/laporan/export/csv' => [[['_route' => 'app_laporan_export_csv', '_controller' => 'App\\Controller\\LaporanController::exportCsv'], null, ['POST' => 0], null, false, false, null]],
        '/admin/laporan/export/pdf' => [[['_route' => 'app_laporan_export_pdf', '_controller' => 'App\\Controller\\LaporanController::exportPdf'], null, ['POST' => 0], null, false, false, null]],
        '/notifikasi' => [[['_route' => 'app_notifikasi_index', '_controller' => 'App\\Controller\\NotifikasiController::index'], null, null, null, true, false, null]],
        '/notifikasi/api/count' => [[['_route' => 'app_notifikasi_api_count', '_controller' => 'App\\Controller\\NotifikasiController::getUnreadCount'], null, null, null, false, false, null]],
        '/notifikasi/api/mark-all-read' => [[['_route' => 'app_notifikasi_mark_all_read', '_controller' => 'App\\Controller\\NotifikasiController::markAllAsRead'], null, ['POST' => 0], null, false, false, null]],
        '/notifikasi/api/latest' => [[['_route' => 'app_notifikasi_api_latest', '_controller' => 'App\\Controller\\NotifikasiController::getLatestNotifications'], null, null, null, false, false, null]],
        '/profile/ganti-password' => [[['_route' => 'app_profile_change_password', '_controller' => 'App\\Controller\\ProfileController::gantiPassword'], null, null, null, false, false, null]],
        '/profile/update-password' => [[['_route' => 'app_profile_update_password', '_controller' => 'App\\Controller\\ProfileController::updatePassword'], null, ['POST' => 0], null, false, false, null]],
        '/profile/profil' => [[['_route' => 'app_profile_view', '_controller' => 'App\\Controller\\ProfileController::viewProfile'], null, null, null, false, false, null]],
        '/profile/profil/edit' => [[['_route' => 'app_profile_edit', '_controller' => 'App\\Controller\\ProfileController::editProfile'], null, ['POST' => 0], null, false, false, null]],
        '/profile/tanda-tangan' => [[['_route' => 'app_profile_tanda_tangan', '_controller' => 'App\\Controller\\ProfileController::tandaTangan'], null, null, null, false, false, null]],
        '/profile/api/tanda-tangan-preview' => [[['_route' => 'app_profile_api_tanda_tangan_preview', '_controller' => 'App\\Controller\\ProfileController::tandaTanganPreview'], null, null, null, false, false, null]],
        '/qr-repair' => [[['_route' => 'app_qr_repair_index', '_controller' => 'App\\Controller\\QRRepairController::index'], null, null, null, true, false, null]],
        '/qr-repair/upload' => [[['_route' => 'app_qr_repair_upload', '_controller' => 'App\\Controller\\QRRepairController::uploadAndRepair'], null, ['POST' => 0], null, false, false, null]],
        '/login' => [[['_route' => 'app_login', '_controller' => 'App\\Controller\\SecurityController::login'], null, null, null, false, false, null]],
        '/logout' => [[['_route' => 'app_logout', '_controller' => 'App\\Controller\\SecurityController::logout'], null, null, null, false, false, null]],
        '/logout-fallback' => [[['_route' => 'app_logout_fallback', '_controller' => 'App\\Controller\\SecurityController::logoutFallback'], null, ['GET' => 0, 'POST' => 1], null, false, false, null]],
        '/logout-secure' => [[['_route' => 'app_logout_secure', '_controller' => 'App\\Controller\\SecurityController::logoutSecure'], null, ['POST' => 0], null, false, false, null]],
        '/admin/struktur-organisasi' => [[['_route' => 'app_struktur_organisasi_index', '_controller' => 'App\\Controller\\StrukturOrganisasiController::index'], null, null, null, true, false, null]],
        '/admin/struktur-organisasi/unit-kerja' => [[['_route' => 'app_admin_unit_kerja', '_controller' => 'App\\Controller\\StrukturOrganisasiController::unitKerja'], null, null, null, false, false, null]],
        '/admin/struktur-organisasi/kepala-bidang' => [[['_route' => 'app_admin_kepala_bidang', '_controller' => 'App\\Controller\\StrukturOrganisasiController::kepalaBidang'], null, null, null, false, false, null]],
        '/admin/struktur-organisasi/kepala-kantor' => [[['_route' => 'app_admin_kepala_kantor', '_controller' => 'App\\Controller\\StrukturOrganisasiController::kepalaKantor'], null, null, null, false, false, null]],
        '/admin/struktur-organisasi/pegawai' => [[['_route' => 'app_admin_pegawai', '_controller' => 'App\\Controller\\StrukturOrganisasiController::pegawai'], null, null, null, false, false, null]],
        '/admin/struktur-organisasi/unit-kerja/create' => [[['_route' => 'app_struktur_organisasi_create_unit', '_controller' => 'App\\Controller\\StrukturOrganisasiController::createUnitKerja'], null, ['POST' => 0], null, false, false, null]],
        '/admin/struktur-organisasi/kepala-bidang/create' => [[['_route' => 'app_struktur_organisasi_create_kepala_bidang', '_controller' => 'App\\Controller\\StrukturOrganisasiController::createKepalaBidang'], null, ['POST' => 0], null, false, false, null]],
        '/admin/struktur-organisasi/kepala-kantor/create' => [[['_route' => 'app_struktur_organisasi_create_kepala_kantor', '_controller' => 'App\\Controller\\StrukturOrganisasiController::createKepalaKantor'], null, ['POST' => 0], null, false, false, null]],
        '/admin/struktur-organisasi/get-all-pegawai' => [[['_route' => 'app_struktur_organisasi_get_all_pegawai', '_controller' => 'App\\Controller\\StrukturOrganisasiController::getAllPegawai'], null, ['GET' => 0], null, false, false, null]],
        '/admin/struktur-organisasi/pegawai/assign-unit' => [[['_route' => 'app_struktur_organisasi_assign_pegawai_unit', '_controller' => 'App\\Controller\\StrukturOrganisasiController::assignPegawaiToUnit'], null, ['POST' => 0], null, false, false, null]],
        '/admin/struktur-organisasi/pegawai/export-template' => [[['_route' => 'app_struktur_organisasi_export_template_pegawai', '_controller' => 'App\\Controller\\StrukturOrganisasiController::exportTemplatePegawai'], null, ['GET' => 0], null, false, false, null]],
        '/admin/struktur-organisasi/pegawai/preview-import' => [[['_route' => 'app_struktur_organisasi_preview_import_pegawai', '_controller' => 'App\\Controller\\StrukturOrganisasiController::previewImportPegawai'], null, ['POST' => 0], null, false, false, null]],
        '/admin/struktur-organisasi/pegawai/import' => [[['_route' => 'app_struktur_organisasi_import_pegawai', '_controller' => 'App\\Controller\\StrukturOrganisasiController::importPegawai'], null, ['POST' => 0], null, false, false, null]],
        '/admin/struktur-organisasi/pegawai/test-import' => [[['_route' => 'app_struktur_organisasi_test_import', '_controller' => 'App\\Controller\\StrukturOrganisasiController::testImport'], null, ['GET' => 0], null, false, false, null]],
        '/admin/struktur-organisasi/get-available-units' => [[['_route' => 'app_struktur_organisasi_get_available_units', '_controller' => 'App\\Controller\\StrukturOrganisasiController::getAvailableUnits'], null, ['GET' => 0], null, false, false, null]],
        '/user/attendance/dashboard' => [[['_route' => 'app_user_attendance_dashboard', '_controller' => 'App\\Controller\\UserAttendanceController::dashboard'], null, null, null, false, false, null]],
        '/user/attendance/api/statistik' => [[['_route' => 'app_user_attendance_api_statistik', '_controller' => 'App\\Controller\\UserAttendanceController::apiStatistik'], null, ['GET' => 0], null, false, false, null]],
        '/user/attendance/perbandingan-bulanan' => [[['_route' => 'app_user_attendance_comparison', '_controller' => 'App\\Controller\\UserAttendanceController::perbandinganBulanan'], null, null, null, false, false, null]],
        '/user/attendance/widget' => [[['_route' => 'app_user_attendance_widget', '_controller' => 'App\\Controller\\UserAttendanceController::widget'], null, null, null, false, false, null]],
        '/user-jadwal' => [[['_route' => 'app_user_jadwal_index', '_controller' => 'App\\Controller\\UserJadwalController::index'], null, null, null, true, false, null]],
        '/kalender' => [[['_route' => 'app_user_kalender', '_controller' => 'App\\Controller\\UserKalenderController::index'], null, null, null, true, false, null]],
        '/kalender/api/riwayat-absensi' => [[['_route' => 'app_user_kalender_riwayat_absensi', '_controller' => 'App\\Controller\\UserKalenderController::riwayatAbsensi'], null, null, null, false, false, null]],
        '/laporan' => [[['_route' => 'app_user_laporan', '_controller' => 'App\\Controller\\UserLaporanController::riwayatAbsensi'], null, null, null, true, false, null]],
    ],
    [ // $regexpList
        0 => '{^(?'
                .'|/_(?'
                    .'|error/(\\d+)(?:\\.([^/]++))?(*:38)'
                    .'|wdt/([^/]++)(*:57)'
                    .'|profiler/(?'
                        .'|font/([^/\\.]++)\\.woff2(*:98)'
                        .'|([^/]++)(?'
                            .'|/(?'
                                .'|search/results(*:134)'
                                .'|router(*:148)'
                                .'|exception(?'
                                    .'|(*:168)'
                                    .'|\\.css(*:181)'
                                .')'
                            .')'
                            .'|(*:191)'
                        .')'
                    .')'
                .')'
                .'|/a(?'
                    .'|bsensi/(?'
                        .'|proses/([^/]++)(*:232)'
                        .'|qr/schedule/([^/]++)(*:260)'
                    .')'
                    .'|dmin/(?'
                        .'|attendance\\-report/pegawai/([^/]++)(*:312)'
                        .'|jadwal\\-absensi/([^/]++)/(?'
                            .'|toggle(*:354)'
                            .'|delete(*:368)'
                            .'|generate\\-qr(*:388)'
                            .'|edit(*:400)'
                            .'|update(*:414)'
                        .')'
                        .'|ba(?'
                            .'|ckup/download/([^/]++)(*:450)'
                            .'|nner/([^/]++)/(?'
                                .'|edit(*:479)'
                                .'|update(*:493)'
                                .'|toggle\\-status(*:515)'
                                .'|delete(*:529)'
                            .')'
                        .')'
                        .'|event/(?'
                            .'|(\\d+)(*:553)'
                            .'|(\\d+)/edit(*:571)'
                            .'|(\\d+)/delete(*:591)'
                            .'|api/toggle\\-status/([^/]++)(*:626)'
                            .'|(\\d+)/download\\-kehadiran(*:659)'
                        .')'
                        .'|laporan\\-(?'
                            .'|bulanan/detail/([^/]++)(*:703)'
                            .'|kehadiran/(?'
                                .'|detail/([^/]++)(*:739)'
                                .'|a(?'
                                    .'|bsensi\\-detail/([^/]++)(*:774)'
                                    .'|pi/detail/([^/]++)(*:800)'
                                .')'
                            .')'
                        .')'
                        .'|role/(?'
                            .'|u(?'
                                .'|pdate\\-user\\-permissions/([^/]++)(*:856)'
                                .'|sers\\-by\\-role/([^/]++)(*:887)'
                            .')'
                            .'|reset\\-user\\-permissions/([^/]++)(*:929)'
                        .')'
                        .'|user/(?'
                            .'|update/([^/]++)(*:961)'
                            .'|delete/([^/]++)(*:984)'
                            .'|get/([^/]++)(*:1004)'
                            .'|toggle\\-status/([^/]++)(*:1036)'
                        .')'
                        .'|validasi\\-absen/(?'
                            .'|approve/([^/]++)(*:1081)'
                            .'|reject/([^/]++)(*:1105)'
                            .'|detail/([^/]++)(*:1129)'
                        .')'
                        .'|struktur\\-organisasi/(?'
                            .'|unit\\-kerja/([^/]++)/(?'
                                .'|edit(*:1191)'
                                .'|update(*:1206)'
                                .'|delete(*:1221)'
                            .')'
                            .'|kepala\\-(?'
                                .'|bidang/([^/]++)/(?'
                                    .'|edit(*:1265)'
                                    .'|update(*:1280)'
                                    .'|delete(*:1295)'
                                .')'
                                .'|kantor/([^/]++)/(?'
                                    .'|edit(*:1328)'
                                    .'|update(*:1343)'
                                    .'|toggle(*:1358)'
                                    .'|delete(*:1373)'
                                .')'
                            .')'
                            .'|pegawai/([^/]++)/(?'
                                .'|remove\\-unit(*:1416)'
                                .'|edit(*:1429)'
                                .'|update(*:1444)'
                            .')'
                        .')'
                    .')'
                .')'
                .'|/file/selfie/([^/]++)(*:1478)'
                .'|/notifikasi/api/mark\\-read/([^/]++)(*:1522)'
                .'|/qr\\-repair/download/([^/]++)(*:1560)'
                .'|/user\\-jadwal/jadwal\\-absensi/([^/]++)/(?'
                    .'|view(*:1615)'
                    .'|update\\-limited(*:1639)'
                .')'
                .'|/kalender/api/(?'
                    .'|events/([^/]++)(*:1681)'
                    .'|absen\\-event/([^/]++)(*:1711)'
                .')'
            .')/?$}sDu',
    ],
    [ // $dynamicRoutes
        38 => [[['_route' => '_preview_error', '_controller' => 'error_controller::preview', '_format' => 'html'], ['code', '_format'], null, null, false, true, null]],
        57 => [[['_route' => '_wdt', '_controller' => 'web_profiler.controller.profiler::toolbarAction'], ['token'], null, null, false, true, null]],
        98 => [[['_route' => '_profiler_font', '_controller' => 'web_profiler.controller.profiler::fontAction'], ['fontName'], null, null, false, false, null]],
        134 => [[['_route' => '_profiler_search_results', '_controller' => 'web_profiler.controller.profiler::searchResultsAction'], ['token'], null, null, false, false, null]],
        148 => [[['_route' => '_profiler_router', '_controller' => 'web_profiler.controller.router::panelAction'], ['token'], null, null, false, false, null]],
        168 => [[['_route' => '_profiler_exception', '_controller' => 'web_profiler.controller.exception_panel::body'], ['token'], null, null, false, false, null]],
        181 => [[['_route' => '_profiler_exception_css', '_controller' => 'web_profiler.controller.exception_panel::stylesheet'], ['token'], null, null, false, false, null]],
        191 => [[['_route' => '_profiler', '_controller' => 'web_profiler.controller.profiler::panelAction'], ['token'], null, null, false, true, null]],
        232 => [[['_route' => 'app_absensi_proses', '_controller' => 'App\\Controller\\AbsensiController::prosesAbsensi'], ['id'], ['GET' => 0, 'POST' => 1], null, false, true, null]],
        260 => [[['_route' => 'app_absensi_generate_qr_by_schedule', '_controller' => 'App\\Controller\\AbsensiController::generateQrBySchedule'], ['id'], null, null, false, true, null]],
        312 => [[['_route' => 'app_admin_attendance_report_pegawai', '_controller' => 'App\\Controller\\AdminAttendanceReportController::detailPegawai'], ['id'], ['GET' => 0], null, false, true, null]],
        354 => [[['_route' => 'app_admin_toggle_jadwal', '_controller' => 'App\\Controller\\AdminController::toggleJadwalStatus'], ['id'], ['POST' => 0], null, false, false, null]],
        368 => [[['_route' => 'app_admin_delete_jadwal_new', '_controller' => 'App\\Controller\\AdminController::deleteJadwalAbsensi'], ['id'], ['DELETE' => 0], null, false, false, null]],
        388 => [[['_route' => 'app_admin_generate_qr', '_controller' => 'App\\Controller\\AdminController::generateQrCode'], ['id'], ['POST' => 0], null, false, false, null]],
        400 => [[['_route' => 'app_admin_edit_jadwal', '_controller' => 'App\\Controller\\AdminController::editJadwal'], ['id'], ['GET' => 0], null, false, false, null]],
        414 => [[['_route' => 'app_admin_update_jadwal', '_controller' => 'App\\Controller\\AdminController::updateJadwal'], ['id'], ['POST' => 0], null, false, false, null]],
        450 => [[['_route' => 'app_admin_backup_download', '_controller' => 'App\\Controller\\AdminController::downloadBackup'], ['filename'], ['GET' => 0], null, false, true, null]],
        479 => [[['_route' => 'app_admin_banner_edit', '_controller' => 'App\\Controller\\AdminSliderController::edit'], ['id'], null, null, false, false, null]],
        493 => [[['_route' => 'app_admin_banner_update', '_controller' => 'App\\Controller\\AdminSliderController::update'], ['id'], ['POST' => 0], null, false, false, null]],
        515 => [[['_route' => 'app_admin_banner_toggle_status', '_controller' => 'App\\Controller\\AdminSliderController::toggleStatus'], ['id'], ['POST' => 0], null, false, false, null]],
        529 => [[['_route' => 'app_admin_banner_delete', '_controller' => 'App\\Controller\\AdminSliderController::delete'], ['id'], ['DELETE' => 0], null, false, false, null]],
        553 => [[['_route' => 'app_admin_event_show', '_controller' => 'App\\Controller\\AdminEventController::show'], ['id'], null, null, false, true, null]],
        571 => [[['_route' => 'app_admin_event_edit', '_controller' => 'App\\Controller\\AdminEventController::edit'], ['id'], null, null, false, false, null]],
        591 => [[['_route' => 'app_admin_event_delete', '_controller' => 'App\\Controller\\AdminEventController::delete'], ['id'], ['POST' => 0], null, false, false, null]],
        626 => [[['_route' => 'app_admin_event_toggle_status', '_controller' => 'App\\Controller\\AdminEventController::toggleStatus'], ['id'], ['POST' => 0], null, false, true, null]],
        659 => [[['_route' => 'app_admin_event_download_kehadiran', '_controller' => 'App\\Controller\\AdminEventController::downloadKehadiran'], ['id'], null, null, false, false, null]],
        703 => [[['_route' => 'app_admin_laporan_bulanan_detail', '_controller' => 'App\\Controller\\AdminLaporanBulananController::detailPegawai'], ['pegawaiId'], null, null, false, true, null]],
        739 => [[['_route' => 'app_admin_laporan_kehadiran_detail_pegawai', '_controller' => 'App\\Controller\\AdminLaporanKehadiranController::detailKehadiran'], ['pegawaiId'], null, null, false, true, null]],
        774 => [[['_route' => 'app_admin_laporan_kehadiran_absensi_detail', '_controller' => 'App\\Controller\\AdminLaporanKehadiranController::detailAbsensi'], ['absensiId'], null, null, false, true, null]],
        800 => [[['_route' => 'app_admin_laporan_kehadiran_detail', '_controller' => 'App\\Controller\\AdminLaporanKehadiranController::getAbsensiDetail'], ['id'], ['GET' => 0], null, false, true, null]],
        856 => [[['_route' => 'app_admin_role_update_user_permissions', '_controller' => 'App\\Controller\\AdminRoleController::updateUserPermissions'], ['id'], ['POST' => 0], null, false, true, null]],
        887 => [[['_route' => 'app_admin_role_users_by_role', '_controller' => 'App\\Controller\\AdminRoleController::getUsersByRole'], ['role'], ['GET' => 0], null, false, true, null]],
        929 => [[['_route' => 'app_admin_role_reset_user_permissions', '_controller' => 'App\\Controller\\AdminRoleController::resetUserPermissions'], ['id'], ['POST' => 0], null, false, true, null]],
        961 => [[['_route' => 'app_admin_user_update', '_controller' => 'App\\Controller\\AdminUserController::update'], ['id'], ['POST' => 0], null, false, true, null]],
        984 => [[['_route' => 'app_admin_user_delete', '_controller' => 'App\\Controller\\AdminUserController::delete'], ['id'], ['DELETE' => 0], null, false, true, null]],
        1004 => [[['_route' => 'app_admin_user_get', '_controller' => 'App\\Controller\\AdminUserController::getUserData'], ['id'], ['GET' => 0], null, false, true, null]],
        1036 => [[['_route' => 'app_admin_user_toggle_status', '_controller' => 'App\\Controller\\AdminUserController::toggleStatus'], ['id'], ['POST' => 0], null, false, true, null]],
        1081 => [[['_route' => 'app_admin_approve_absensi', '_controller' => 'App\\Controller\\AdminValidasiAbsenController::approveAbsensi'], ['id'], ['POST' => 0], null, false, true, null]],
        1105 => [[['_route' => 'app_admin_reject_absensi', '_controller' => 'App\\Controller\\AdminValidasiAbsenController::rejectAbsensi'], ['id'], ['POST' => 0], null, false, true, null]],
        1129 => [[['_route' => 'app_admin_detail_absensi', '_controller' => 'App\\Controller\\AdminValidasiAbsenController::detailAbsensi'], ['id'], ['GET' => 0], null, false, true, null]],
        1191 => [[['_route' => 'app_struktur_organisasi_edit_unit', '_controller' => 'App\\Controller\\StrukturOrganisasiController::getUnitKerja'], ['id'], ['GET' => 0], null, false, false, null]],
        1206 => [[['_route' => 'app_struktur_organisasi_update_unit', '_controller' => 'App\\Controller\\StrukturOrganisasiController::updateUnitKerja'], ['id'], ['POST' => 0], null, false, false, null]],
        1221 => [[['_route' => 'app_struktur_organisasi_delete_unit', '_controller' => 'App\\Controller\\StrukturOrganisasiController::deleteUnitKerja'], ['id'], ['DELETE' => 0], null, false, false, null]],
        1265 => [[['_route' => 'app_struktur_organisasi_edit_kepala_bidang', '_controller' => 'App\\Controller\\StrukturOrganisasiController::getKepalaBidang'], ['id'], ['GET' => 0], null, false, false, null]],
        1280 => [[['_route' => 'app_struktur_organisasi_update_kepala_bidang', '_controller' => 'App\\Controller\\StrukturOrganisasiController::updateKepalaBidang'], ['id'], ['POST' => 0], null, false, false, null]],
        1295 => [[['_route' => 'app_struktur_organisasi_delete_kepala_bidang', '_controller' => 'App\\Controller\\StrukturOrganisasiController::deleteKepalaBidang'], ['id'], ['DELETE' => 0], null, false, false, null]],
        1328 => [[['_route' => 'app_struktur_organisasi_edit_kepala_kantor', '_controller' => 'App\\Controller\\StrukturOrganisasiController::getKepalaKantor'], ['id'], ['GET' => 0], null, false, false, null]],
        1343 => [[['_route' => 'app_struktur_organisasi_update_kepala_kantor', '_controller' => 'App\\Controller\\StrukturOrganisasiController::updateKepalaKantor'], ['id'], ['POST' => 0], null, false, false, null]],
        1358 => [[['_route' => 'app_struktur_organisasi_toggle_kepala_kantor', '_controller' => 'App\\Controller\\StrukturOrganisasiController::toggleKepalaKantor'], ['id'], ['POST' => 0], null, false, false, null]],
        1373 => [[['_route' => 'app_struktur_organisasi_delete_kepala_kantor', '_controller' => 'App\\Controller\\StrukturOrganisasiController::deleteKepalaKantor'], ['id'], ['DELETE' => 0], null, false, false, null]],
        1416 => [[['_route' => 'app_struktur_organisasi_remove_pegawai_unit', '_controller' => 'App\\Controller\\StrukturOrganisasiController::removePegawaiFromUnit'], ['id'], ['POST' => 0], null, false, false, null]],
        1429 => [[['_route' => 'app_struktur_organisasi_edit_pegawai', '_controller' => 'App\\Controller\\StrukturOrganisasiController::getPegawai'], ['id'], ['GET' => 0], null, false, false, null]],
        1444 => [[['_route' => 'app_struktur_organisasi_update_pegawai', '_controller' => 'App\\Controller\\StrukturOrganisasiController::updatePegawai'], ['id'], ['POST' => 0], null, false, false, null]],
        1478 => [[['_route' => 'app_file_selfie', '_controller' => 'App\\Controller\\FileController::selfie'], ['filename'], null, null, false, true, null]],
        1522 => [[['_route' => 'app_notifikasi_mark_read', '_controller' => 'App\\Controller\\NotifikasiController::markAsRead'], ['id'], ['POST' => 0], null, false, true, null]],
        1560 => [[['_route' => 'app_qr_repair_download', '_controller' => 'App\\Controller\\QRRepairController::downloadRepaired'], ['filename'], null, null, false, true, null]],
        1615 => [[['_route' => 'app_user_view_jadwal', '_controller' => 'App\\Controller\\UserJadwalController::viewJadwalAbsensi'], ['id'], ['GET' => 0], null, false, false, null]],
        1639 => [[['_route' => 'app_user_update_jadwal', '_controller' => 'App\\Controller\\UserJadwalController::updateJadwalLimited'], ['id'], ['POST' => 0], null, false, false, null]],
        1681 => [[['_route' => 'app_user_kalender_api_events', '_controller' => 'App\\Controller\\UserKalenderController::getEventsByDate'], ['date'], null, null, false, true, null]],
        1711 => [
            [['_route' => 'app_user_kalender_absen_event', '_controller' => 'App\\Controller\\UserKalenderController::absenEvent'], ['id'], ['POST' => 0], null, false, true, null],
            [null, null, null, null, false, false, 0],
        ],
    ],
    null, // $checkCondition
];
